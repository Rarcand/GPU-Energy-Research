Install requirements.txt in a Python 3.11 virtual environment. Run `make figures` to regenerate the paper tables and figures from the packaged predictions. Run `make precision` to reproduce the separate FP16 and BF16 comparisons using 3 passes on every eligible GPU. Run `make replay` to refit the source models and replay four target measurements before scoring each winner on a separate pass.

dataset.zip contains the original four-environment benchmark, frozen inputs, and held-out shape assignments. matched-timings.zip contains the five-environment timing measurements for the independent-pass comparison. Its coverage.json records each device and precision. The A100 evaluation in this version uses 3 passes. All other targets use three passes. The T4 supports the FP16 grid. The other four targets also support the BF16 grid.

In the independent-winners traces, the three regret entries correspond to the Gaussian surrogate with feedback, the same surrogate with feedback disabled, and adaptive geometry ridge. Selection and scoring indices identify the ordered measurement passes.

The five-device fixed-portfolio comparison is in benchmark/independent-portfolio-summary.csv. Run `make portfolio` to refit the source policies and replay budgets 1, 2, 4, and 8 using all six ordered pass pairs. Run `make portfolio-summary` to rebuild the estimates, table and figure from the packed independent-portfolio traces. Reported intervals are paired shape bootstraps, conditional on the measured devices.

The current measurement entry points and common timer are in collection/. Historical receipts in receipts/ identify the original runs used for replay. The recorded hashes refer to those historical collectors.
